package com.dhanashree.MyBankApp.controller;

import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.json.simple.JSONObject;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.dhanashree.MyBankApp.dto.CustomerDataDto;
import com.dhanashree.MyBankApp.dto.*;
import com.dhanashree.MyBankApp.service.IBankService;

@RestController
public class BankController {
	
@Autowired
IBankService bankservice;



@RequestMapping(value = "/saveCustomerDetails", method = RequestMethod.POST)
public List<CustomerDataEntity> saveCustomerDetails(@RequestBody List<CustomerDataDto> customerData ) {
  return bankservice.saveCustomerData(customerData);
}

@RequestMapping(value = "/uploadDocument", method = RequestMethod.POST)

public ResponseEntity < String > handleFileUpload(@RequestParam("file") MultipartFile file) {
 String message = "";
 try {
	 bankservice.store(file);
  message = "You successfully uploaded " + file.getOriginalFilename() + "!";
  return ResponseEntity.status(HttpStatus.OK).body(message);
 } catch (Exception e) {
  message = "Fail to upload Profile Picture........" + file.getOriginalFilename() + "!";
  return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
 }
}

@RequestMapping(value = "/authenticateuser", method = RequestMethod.POST, 
produces = "application/json", consumes = "application/json", headers = "Accept=application/json")
public CustomerDataDto AuthenticateUser(@RequestBody JSONObject jsnObject)
{
return bankservice.validateForIPIN(jsnObject);

}


@RequestMapping(value="/verifyOTP",method = RequestMethod.GET)

public JSONObject OTPVerification(@RequestParam int otp){
	return bankservice.VerifyOTP(otp,bankservice.generateOTP());
}


}
