package com.dhanashree.MyBankApp.repositories;

import org.springframework.data.repository.CrudRepository;

import com.dhanashree.MyBankApp.dto.CustomerDataEntity;

	public interface UserRepository extends CrudRepository<CustomerDataEntity,Long>{
}
