package com.dhanashree.MyBankApp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.dhanashree.MyBankApp.dto.CustomerDataEntity;

public interface CustomerDetailRepository extends JpaRepository<CustomerDataEntity, Long> {

	@Query("select e from CustomerDataEntity e where e.mobile=?1")
	CustomerDataEntity findByMob(Long mobile);
		
}
