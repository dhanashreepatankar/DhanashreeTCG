package com.dhanashree.MyBankApp.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

//import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import com.dhanashree.MyBankApp.dto.CustomerDataDto;
import com.dhanashree.MyBankApp.dto.CustomerDataEntity;
import com.dhanashree.MyBankApp.dto.ResponseDto;
import com.dhanashree.MyBankApp.repositories.CustomerDetailRepository;
import com.dhanashree.MyBankApp.repositories.UserRepository;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.stream.Stream;

import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;

import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLHandshakeException;

import java.net.*;
import java.io.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class BankServiceImpl implements IBankService {
    private static final Logger LOGGER = LoggerFactory.getLogger(BankServiceImpl.class);
@Autowired
CustomerDetailRepository customerDetailRepository;

@Autowired
UserRepository userrepo;

@Autowired
IBankService bankservice;

//Logger log = LoggerFactor.getLogger(this.getClass().getName());
//private final Path rootLocation = Paths.get("filestorage");
private final Path rootLocation = Paths.get("ProfilePictureStore");

public static final String PROXY_URL = "cis-india-pitc-bangalorez.proxy.corporate.ge.com";
public static final int PORT_NUMBER = 80;
public static final String HTTP_STRING = "http";

static final String _userName = "9421824198";
static final String _password = "yahoodha35";
static final String _url = "http://ubaid.tk/sms/sms.aspx";
static final String _loginUrl = "https://smsapi.engineeringtgr.com/login/?Mobile=&Password=";
static final String _sendUrl = "https://smsapi.engineeringtgr.com/send/?Mobile=&Password=&Message=&To=&Key=";
static final String charset = "UTF-8";
//static final String message = "TestMessage34";
static final String apiKey = "dhanamtex8wfsEJlNWDPFXp";



@Override
public void store(MultipartFile file){
	System.out.println("fffffffff"+file);
	try {
		
		System.out.println("hi"+rootLocation.toUri());
        Files.copy(file.getInputStream(), this.rootLocation.resolve(file.getOriginalFilename()));
        System.out.println("aaaaaaa"+file.getOriginalFilename());
        System.out.println(rootLocation.toUri());
    } catch (Exception e) {
    	throw new RuntimeException("FAIL! -> message = " + e.getMessage());
    }
}

@Override
public List<CustomerDataEntity> saveCustomerData(List<CustomerDataDto> customerData){
	
	CustomerDataEntity customerdataEntity= null;
	List<CustomerDataEntity> customerlist = new ArrayList<CustomerDataEntity>();
	
	for(CustomerDataDto customerdataDto:customerData){
		
		customerdataEntity= new CustomerDataEntity();
		customerdataEntity.setCustomernumber(customerdataDto.getCustomernumber());
		customerdataEntity.setCustomerId(customerdataDto.getCustomerId());
		customerdataEntity.setCustomerName(customerdataDto.getCustomerName());
		customerdataEntity.setCustomerAccountNumber(customerdataDto.getCustomerAccountNumber());
		customerdataEntity.setCustomerAddhar(customerdataDto.getCustomerAddhar());
		customerdataEntity.setCustomerAddress(customerdataDto.getCustomerAddress());
		customerdataEntity.setDateAcc(customerdataDto.getDateAcc());
		customerdataEntity.setMobile(customerdataDto.getMobile());
		customerdataEntity.setPanNumber(customerdataDto.getPanNumber());
		customerlist.add(customerDetailRepository.save(customerdataEntity));
	}
	return customerlist;
	
}

@Override
public CustomerDataDto validateForIPIN(JSONObject user) {
	CustomerDataDto  responseDto = new CustomerDataDto();
	System.out.println("======"+user);
    try{
    	System.out.println("inside try.....lll"+user.get("mobile"));
//    	Object mo = user.get("mobile");
//    	System.out.println("key"+mo);
    
    	
long mobile1 =(long) user.get("mobile");
// long mobile=(long) user.get("mobile");
    	
Long mobile= Long.valueOf(mobile1);

//System.out.println("mobileeee"+mobile);

//	Long mobile =(long) 0;

	String panNumber = (String)user.get("panNumber");
	System.out.println("panNumber"+panNumber);
	System.out.println("................"+mobile+panNumber);
	CustomerDataEntity userEntity=null;
	if(mobile != null && panNumber != null && panNumber != "") {
		userEntity = customerDetailRepository.findByMob(mobile);
		
		System.out.println("lllll"+customerDetailRepository.findByMob(mobile));
		System.out.println("userEntity"+userEntity);
	}
	if(userEntity != null && userEntity.getPanNumber().contentEquals(panNumber)){
		System.out.println("lllllmmmmm");
		responseDto.setMobile(userEntity.getMobile());
		responseDto.setCustomerId(userEntity.getCustomerId());
		responseDto.setValid(true);
		System.out.println("mob............."+mobile.toString());
		//buildRequestString(mobile.toString(),message);
//		sendSMS(mobile.toString(),message);
		
		//random number
		
				//Random rnd = new Random();
//				int OTPnumber = 100000 + rnd.nextInt(900000);
		int OTPnumber=generateOTP();
				System.out.println("random"+OTPnumber);
				
				String message="Dear Customer,"
						+ "\n"+Integer.toString(OTPnumber)+ " is your one time password(OTP). Please enter OTP to proceed."+"\n"+"Please do not share with anyone"+
						"\n"+
						"Thank You";
		String mesg=Integer.toString(OTPnumber);
	    //sendSMSTest(_userName,_password,message,mobile.toString(),apiKey);
	  System.out.println("message///////"+mesg);
	    System.out.println("mob....."+_userName+"pass"+_password+"rec mob "+mobile.toString()+"api"+apiKey);
	   
	  
		System.out.println("mob............."+mobile.toString());
		
		
	}else{
		System.out.println("llllljjjjj");
		responseDto.setMobile(0);
		responseDto.setValid(false);
	}
    }catch(Exception e){
    	 LOGGER.error("Something went wrong",e.getMessage());
    	responseDto.setMobile(0);
		responseDto.setValid(false);
    	
    }
    return responseDto;
}


//@Override
//public List<UserDetailsDto> getAllUserData() {
//	List<UserDetailsDto> userDetailsDtos = null;
//	userDetailsDtos = new ArrayList<>();
//
//	Date today = new Date();
//	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//	String today1 = dateFormat.format(today);
//	System.out.println("todays date string  ...... " + today1);
//
//	List<UserDetailsEntity> userDetailsEntityList = userDetailsRepository.getUsersByBirthdate();
//	for (UserDetailsEntity userDetailsEntity : userDetailsEntityList) {
//		Date bday = userDetailsEntity.getBirthDate();
//		Timestamp bday1 = new Timestamp(bday.getTime());
//		// System.out.println("timestamp bady ......... "+bday1);
//		Date date = new Date(bday1.getTime());
//		String bday2 = dateFormat.format(date);
//		System.out.println("bday string  ........ " + bday2);
//		if (today1.equals(bday2)) {
//			ArrayList<Long> contactList = (ArrayList<Long>) userDetailsRepository.getPhoneNumberByBday(date);
//			System.out.println("list of contact equals .... " + contactList);
//			for(int i=0; i < contactList.size(); i++ ){
//				try {
////					buildRequestString(contactList.get(i).toString(),message);
////					sendSMS(contactList.get(i).toString(),message);
//					sendSMSTest(_userName,_password,message,contactList.get(i).toString(),apiKey);
//				} catch (Exception e) {
//					
//					e.printStackTrace();
//				}
//			}
//			
//		}
//		UserDetailsDto userDetailsDtoMapper = mapper.userDetailsMapping(userDetailsEntity);
//		userDetailsDtos.add(userDetailsDtoMapper);
//	}
//
//	return userDetailsDtos;
//}

private void sendSMSTest(String username, String password, String message2, String to, String apikey2) throws KeyManagementException, NoSuchAlgorithmException {
//	try {
//		System.out.println("send sms try 1");
//		System.out.println("to mob  "+to);
	//Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cis-india-pitc-bangalorez.proxy.corporate.ge.com", 80));
//		System.out.println("mob.....ssss.. "+username+"pass"+password+"rec mob "+to+"api"+apikey2);
////        URL url = new URL("https://smsapi.engineeringtgr.com/send/?Mobile=username&Password=password&Message=message2&To=to&Key=apikey2");
//		 // URL url = new URL("https://smsapi.engineeringtgr.com/send/?"+buildRequestString(to,message2));
//		URL url=new URL("https://smsapi.engineeringtgr.com/send/?Mobile=9421824198&Password=yahoodha35&Message=hi&To=9421824198&Key=dhanamtex8wfsEJlNWDPFXp");
//     System.out.println("url  ........  "+url);
//        URLConnection urlcon = url.openConnection();
//       
        
        //test
//        HttpURLConnection connection = null;
//        URL serverAddress = null;
//        serverAddress = new URL("https://smsapi.engineeringtgr.com/send/?Mobile=9421824198&Password=yahoodha35&Message=hi&To=9421824198&Key=dhanamtex8wfsEJlNWDPFXp");
//        //set up out communications stuff
//        connection = null;
//       
//        //Set up the initial connection
//        connection = (HttpURLConnection)serverAddress.openConnection();
//        connection.setRequestMethod("GET");
//        connection.setDoOutput(true);
//        connection.setDoInput(true);
//        connection.setUseCaches(false);
//        connection.setRequestProperty ( "Content-type","text/xml" ); 
//        connection.setAllowUserInteraction(false);
//        String strData = URLEncoder.encode("test","UTF-8");
//        connection.setRequestProperty ( "Content-length", "" + strData.length ());  
//        connection.setReadTimeout(10000);
//        connection.connect();
//        
//        

      //test 2
        HttpURLConnection connection = null;
        DataOutputStream wr = null;
        BufferedReader rd  = null;
        StringBuilder sb = null;
        String line = null;
       
        URL serverAddress = null;
       
        try {
//        	String finalUrl="https://smsapi.engineeringtgr.com/send/?Mobile=9421824198&Password=yahoodha35&Message=hiDhaPat&To=9421824198&Key=dhanamtex8wfsEJlNWDPFXp";
////        	HttpPost post = new HttpPost(finalUrl);
//        	   HttpHost proxy = new HttpHost(PROXY_URL,PORT_NUMBER, HTTP_STRING);
        	   Proxy proxy1= new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_URL, PORT_NUMBER));
			// RequestConfig config = RequestConfig.custom().setProxy(proxy)
			// .build();
			// post.setConfig(config);
        	//String url1 = "https://smsapi.engineeringtgr.com/send/?Mobile=9421824198&Password=yahoodha35&Message=hiDhaPat&To=9421824198&Key=dhanamtex8wfsEJlNWDPFXp";
//        	 String url1="http://www.google.com/search";
//        	serverAddress = (URL)new URL(url1.trim());
          //serverAddress = new URL("https://smsapi.engineeringtgr.com/send/?Mobile=9421824198&Password=yahoodha35&Message=hiDhaPat&To=9421824198&Key=dhanamtex8wfsEJlNWDPFXp");
            //set up out communications stuff
          //  connection = null;
           
               
               //Proxy proxy1 = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cis-india-pitc-bangalorez.proxy.corporate.ge.com", 80));
//               URL url = new URL("https://smsapi.engineeringtgr.com/send/?Mobile=username&Password=password&Message=message2&To=to&Key=apikey2");
//               URLConnection urlcon = url.openConnection(proxy1);
//               
        	   
        	   //ssl
        	   SSLContext ctx = SSLContext.getInstance("TLS");
               ctx.init(new KeyManager[0], new TrustManager[] {new DefaultTrustManager()}, new SecureRandom());
               SSLContext.setDefault(ctx);
               
          // URL url = new URL("https://smsapi.engineeringtgr.com/send/?Mobile=9421824198&Password=yahoodha35&Message=hiDhaPat&To=9421824198&Key=dhanamtex8wfsEJlNWDPFXp");
          
               URL url = new URL("https://smsapi.engineeringtgr.com/send/?"+buildRequestString(to,message2));
               URLConnection urlcon = url.openConnection(proxy1);
            //urlcon.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");
            InputStream stream = urlcon.getInputStream();
            int i;
            String response="";
            while ((i = stream.read()) != -1) {
                response+=(char)i;
            }
            if(response.contains("success")){
                System.out.println("Successfully send SMS");
                //your code when message send success
            }else{
                System.out.println(response);
                //your code when message not send
            }
            
           
           
            //read the result from the server
//            rd  = new BufferedReader(new InputStreamReader(connection.getInputStream()));
//            sb = new StringBuilder();
//           
//            while ((line = rd.readLine()) != null)
//            {
//                sb.append(line + '\n');
//            }
//           
//            System.out.println(sb.toString());
                       
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally
        {
            //close the connection, set all objects to null
//            connection.disconnect();
//            rd = null;
//            sb = null;
//            wr = null;
//            connection = null;
        }
//        
//        System.out.println("test 1");
//        HttpURLConnection sendConnection = (HttpURLConnection) url.openConnection();
//        System.out.println("test 2");
//        sendConnection.connect();
//        System.out.println("test 3");
//        sendConnection.getInputStream();
//        System.out.println("connect");
//    	InputStream response1 = sendConnection.getInputStream();
//    	
//        BufferedReader br = new BufferedReader(new InputStreamReader(response1));
//        System.out.println("br......"+br);
        //test end
        
        
        
        
//        System.out.println("jjjjjjjjjjjjjj");
//        InputStream stream = urlcon.getInputStream();
//        System.out.println(stream);
//        int i;
//        String response="";
//        System.out.println("kkkkkkkkkkkkkkk");
//        while ((i = stream.read()) != -1) {
//        	
//            response+=(char)i;
//            System.out.println("nnnnnnnnn"+response);
//        }
//        if(response.contains("success")){
//            System.out.println("Successfully send SMS");
//            
//            //your code when message send success
//        }else{
//            System.out.println(response);
//            //your code when message not send
//        }
//    } catch (IOException e) {
//        System.out.println(e.getMessage());
//    }
	
}

private String buildRequestString(String targetPhoneNo, String sms) throws UnsupportedEncodingException {
	
	System.out.println("Inside buildRequestString");
	
	String [] params = new String [5];
	params[0] = _userName;
	params[1] = _password;
	params[2] = sms;
	params[3] = targetPhoneNo;
	params[4] = apiKey;

	String query = String.format("Mobile=%s&Password=%s&Message=%s&To=%s&Key=%s",
			URLEncoder.encode(params[0],charset),
			URLEncoder.encode(params[1],charset),
			URLEncoder.encode(params[2],charset),
			URLEncoder.encode(params[3],charset),
			URLEncoder.encode(params[4],charset)
			);
	
 System.out.println("qqqqqqq"+query);
	return query;
	
}

private String buildRequestString1(String targetPhoneNo, String sms) throws UnsupportedEncodingException {
	 https://smsapi.engineeringtgr.com/send/?Mobile=9421824198&Password=yahoodha35&Message=hi&To=9421824198&Key=dhanamtex8wfsEJlNWDPFXp
	System.out.println("Inside buildRequestString");
	
	String [] params = new String [5];
	params[0] = _userName;
	params[1] = _password;
	params[2] = sms;
	params[3] = targetPhoneNo;
	params[4] = "way2sms";
	
	String query = String.format("uid=%s&pwd=%s&msg=%s&phone=%s&provider=%s",
			URLEncoder.encode(params[0],charset),
			URLEncoder.encode(params[1],charset),
			URLEncoder.encode(params[2],charset),
			URLEncoder.encode(params[3],charset),
			URLEncoder.encode(params[4],charset)
			);
	
 System.out.println("qqqqqqq"+query);
	return query;
	
}

private ResponseDto sendSMS(String reciever, String message) throws Exception {
	
	System.out.println("Inside sendSMS");
	
	ResponseDto response = new ResponseDto();
	Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cis-india-pitc-bangalorez.proxy.corporate.ge.com:80", 80));
	 URL url=new URL(_url + "?" + buildRequestString(reciever,message));
	 URLConnection connection=url.openConnection(proxy);
//	URLConnection connection =( new URL(_url + "?" + buildRequestString(reciever,message))).openConnection(proxy);
	 
	System.out.println("Inside sendSMS2");
	connection.setRequestProperty("Accept-Charset", charset);
	System.out.println("Inside sendSMS3");
	
	InputStream response1 = connection.getInputStream();
	
    
    
	System.out.println("Inside sendSMS4");
	BufferedReader br = new BufferedReader(new InputStreamReader(response1));
	System.out.println("Inside sendSMS5");
	System.out.println(br.readLine());
	response.setSuccess(true);
	response.setData("SMS send Successfully.......");
	
	return response;

}


private static class DefaultTrustManager implements X509TrustManager {

	 @Override
     public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {}

     @Override
     public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {}

     @Override
     public X509Certificate[] getAcceptedIssuers() {
         return null;
     }
 }


@Override
public JSONObject VerifyOTP(int otp,int OTPnumber) {
	//int OTPnumber=generateOTP();
	System.out.println("inside verify otp");
	if(otp==OTPnumber){
		System.out.println("otppppp  "+otp+" "+OTPnumber);
	}
	System.out.println("otppppp  "+otp+" "+OTPnumber);
	return null;
    
}

public int generateOTP(){
	System.out.println("inside generate otp");
	Random rnd = new Random();
	  int OTPnumber=100000 + rnd.nextInt(900000);;
	  System.out.println("ottttp"+OTPnumber);
	return OTPnumber;
	
}


}
