package com.dhanashree.MyBankApp.dto;

import java.util.Date;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "customer_Data3")
public class CustomerDataEntity {


//    @SequenceGenerator(name = "seq", sequenceName = "customer_seq")
//    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")

	@Column
	@SequenceGenerator(name = "seq", sequenceName = "customer_seq")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	private long customernumber;
	
	
	@Id
    private long customerId;
	
	

	@Column
	private String customerName;
	    
	@Override
	public String toString() {
		return "CustomerDataEntity [customernumber=" + customernumber + ", customerId=" + customerId + ", customerName="
				+ customerName + ", customerAddress=" + customerAddress + ", customerAccountNumber="
				+ customerAccountNumber + ", customerAddhar=" + customerAddhar + ", mobile=" + mobile + ", dateAcc="
				+ dateAcc + ", panNumber=" + panNumber + "]";
	}

	@Column
	private String customerAddress;
	 
	@Column
	 private long customerAccountNumber;
	    
	@Column
	 private long customerAddhar;
	
	@Column
	 private long mobile;
	
	@Column
	private Date dateAcc;
	
	@Column
	private String panNumber;
	
	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public long getCustomerAccountNumber() {
		return customerAccountNumber;
	}

	public void setCustomerAccountNumber(long customerAccountNumber) {
		this.customerAccountNumber = customerAccountNumber;
	}

	public long getCustomerAddhar() {
		return customerAddhar;
	}

	public void setCustomerAddhar(long customerAddhar) {
		this.customerAddhar = customerAddhar;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public Date getDateAcc() {
		return dateAcc;
	}

	public void setDateAcc(Date dateAcc) {
		this.dateAcc = dateAcc;
	}
	public long getCustomernumber() {
		return customernumber;
	}

	public void setCustomernumber(long customernumber) {
		this.customernumber = customernumber;
	}
}
