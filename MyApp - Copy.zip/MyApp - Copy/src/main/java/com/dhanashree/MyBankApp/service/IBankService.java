package com.dhanashree.MyBankApp.service;

import java.util.List;

//import org.json.JSONObject;
import org.springframework.web.multipart.MultipartFile;
import org.json.simple.JSONObject;
import com.dhanashree.MyBankApp.dto.CustomerDataDto;
import com.dhanashree.MyBankApp.dto.CustomerDataEntity;



public interface IBankService {

	List<CustomerDataEntity> saveCustomerData(List<CustomerDataDto> customerData);

	void store(MultipartFile file);

//	public  CustomerDataDto validateForIPIN(JSONObject user);


	public CustomerDataDto validateForIPIN( JSONObject user);



	public JSONObject VerifyOTP(int otp, int OTPnumber);

	int generateOTP();




	



}
