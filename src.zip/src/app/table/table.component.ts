import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {

  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  dataSource = ELEMENT_DATA;
  abc=[
    {"seg":1,
  "cost":10,
"vol":34},

{"seg":2,
"cost":10,
"vol":34},

{"seg":3,
"cost":10,
"vol":34},

{"seg":4,
"cost":10,
"vol":34},

{"seg":5,
"cost":10,
"vol":34},

{"seg":6,
"cost":10,
"vol":34},

{"seg":7,
"cost":10,
"vol":34},


{"seg":8,
"cost":10,
"vol":34},


{"seg":9,
"cost":10,
"vol":34},

  ];

  inputvalue:any=[]
  constructor() { }

  ngOnInit() {
  }
  onvlur(e,i){
    if(!e){
      alert("please enter value")

    }
    if(e){
     const obj={
        "value":e,
        "index":i
      }
      this.inputvalue.push(obj)
      console.log(obj)
    }

    console.log(e,i)
  }

}


export interface PeriodicElement {

  position: number;
  weight: number;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, weight: 1.0079, symbol: 'H'},
  {position: 2,  weight: 4.0026, symbol: 'He'},
  {position: 3,  weight: 6.941, symbol: 'Li'},
  {position: 4,  weight: 9.0122, symbol: 'Be'},
  {position: 5,  weight: 10.811, symbol: 'B'},

];
