import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerIDComponent } from './customer-id.component';

describe('CustomerIDComponent', () => {
  let component: CustomerIDComponent;
  let fixture: ComponentFixture<CustomerIDComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerIDComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerIDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
