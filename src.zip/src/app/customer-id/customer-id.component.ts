import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { DatasubmitService } from 'src/app/datasubmit.service';
@Component({
  selector: 'app-customer-id',
  templateUrl: './customer-id.component.html',
  styleUrls: ['./customer-id.component.css']
})
export class CustomerIDComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  dataSource = ELEMENT_DATA;

  // array=[1,2,3]
  // showdata = {};

  isLinear = true;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  rString
  abc
  constructor(private _formBuilder: FormBuilder,private myservice: DatasubmitService) {
    this.firstFormGroup = this._formBuilder.group({
      mobile: ['', Validators.required],
      pan:['',Validators.required],
      captcha:['',Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
  }

  ngOnInit() {

    this.rString = this.randomString(6, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');
    console.log("rString",this.rString)
    
  }


  randomString(length, chars) {
    var result = '';
    for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
    return result;
}
 
randomStringGen(){
  this.rString = this.randomString(6, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');
}

captchaValidate(e){

  console.log("hiiiiiii",this.rString,e.captcha)
  if(e.captcha!=this.rString){
    alert("please enter valid captcha")
    this.rString = this.randomString(6, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');
    this.abc=true;
  }else{
    this.abc=false;
  }

}

submitDetails(e){
  console.log(e)
  
}



exportExcel() {

  console.log("export Export")
  // if (this.dataSource > 0) {
  //   this.myservice.JSONToCSVConvertor(this.data, 'AssignmentExport', true);
  // } else {
  //   this.myservice.JSONToCSVConvertor(this.bgcReport, 'AssignmentExport', true);
  // }
  this.myservice.JSONToCSVConvertor(this.dataSource, 'AssignmentExport', true);
}

// onClick(item) {
 
//   this.showdata[item] = true;
// }
}

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
  {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
  {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
  {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
  {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C'},
  {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
  {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
  {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
  {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
];