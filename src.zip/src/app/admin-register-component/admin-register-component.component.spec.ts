import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminRegisterComponentComponent } from './admin-register-component.component';

describe('AdminRegisterComponentComponent', () => {
  let component: AdminRegisterComponentComponent;
  let fixture: ComponentFixture<AdminRegisterComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminRegisterComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminRegisterComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
