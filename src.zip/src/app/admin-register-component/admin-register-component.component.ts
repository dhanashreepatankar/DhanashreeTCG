import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormsModule, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { DatasubmitService } from 'src/app/datasubmit.service';
import { HttpClient, HttpResponse, HttpEventType } from '@angular/common/http';
@Component({
  selector: 'app-admin-register-component',
  templateUrl: './admin-register-component.component.html',
  styleUrls: ['./admin-register-component.component.css']
})
export class AdminRegisterComponentComponent implements OnInit {
  form;
  date = new Date();

  
selectedFiles: FileList;
currentFileUpload: File;
url = '';
  constructor(private fb: FormBuilder, private myservice: DatasubmitService) {
    this.form = this.fb.group({
      customerId: [null],
      customerName: [null],
      customerAddress: [null],
      customerAccountNumber: [null],
      customerAddhar: [null],
      mobile: [null],



    })
  }

  ngOnInit() {

  }

  submitUserInfo(event) {
    console.log("data event", event);

    let userData = [{
      "customerId": event.customerId,
      "customerName": event.customerName,
      "customerAddress": event.customerAddress,
      "customerAccountNumber": event.customerAccountNumber,
      "customerAddhar": event.customerAddhar,
      "mobile": event.mobile,
      "dateAcc": this.date
    }]
    console.log("submitted data..", userData)
    this.myservice.submitCustomerData(userData)
      .subscribe(
        returnData => {
          console.log("body1", returnData)
        }
      )
  }


  selectFile(event) {
    this.selectedFiles = event.target.files;
   
    
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed
        // this.url = event.target.result;
      }
    }
  }
  upload() {
    this.currentFileUpload = this.selectedFiles.item(0);
    this.myservice.pushFileToStorage(this.currentFileUpload).subscribe(event => {
     if (event instanceof HttpResponse) {
        console.log('File is completely uploaded!');
      }
    });
    this.selectedFiles = undefined;
  }
}
