import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders, HttpRequest, HttpEvent } from '@angular/common/http';

import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class DatasubmitService {

  url="http://localhost:8080/saveCustomerDetails"
 
  constructor(private http: HttpClient) { }

  submitCustomerData(body){
    return this.http.post(this.url,body)
  }



  pushFileToStorage(file: File): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    const req = new HttpRequest('POST', 'http://localhost:8080/uploadDocument', formdata, {
      reportProgress: true,
      responseType: 'text'
    }
    );
    return this.http.request(req);
  }


//   pushFileToStorage(fileToUpload: File) {
//     const endpoint = 'http://localhost:8080/uploadDocument';
//     const formData: FormData = new FormData();
//     // formData.append('fileKey', fileToUpload, fileToUpload.name);
//     return this.http
//       .post(endpoint, formData,{
//         reportProgress: true,
//         responseType: 'text'
//       })
      
// }

JSONToCSVConvertor = function(JSONData, ReportTitle, ShowLabel) {
  var arrData = typeof JSONData !== 'object' ? JSON.parse(JSONData) : JSONData;
  var CSV = '';
  if (ShowLabel) {
    var row = "";
    for (var index in arrData[0]) {
  if(arrData[0]){
      row += index + ',';
    }
    }
    row = row.slice(0, -1);
    CSV += row + '\r\n';
  }
  for (var i = 0; i < arrData.length; i++) {
    var row2 = "";
    for (var index2 in arrData[i]) {
  if(arrData[i][index2]){
      row2 += '"' + arrData[i][index2] + '",';
    }
  }
   row2= row2.slice(0, row2.length - 1);
    CSV += row2 + '\r\n';
  }
  if (CSV === '') {
    return;
  }
  var fileName = "Report_";
  fileName += ReportTitle.replace(/ /g, "_");
  var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
  var link = document.createElement("a");
  link.href = uri;
  // link.style = "visibility:hidden";
  link.download = fileName + ".csv";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
    };
  }

