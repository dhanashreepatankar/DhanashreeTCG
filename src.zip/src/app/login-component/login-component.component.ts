import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {

  email = new FormControl('', [Validators.required, Validators.email]);
  hide = true;
  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :
        this.email.hasError('email') ? 'Not a valid email' :
            '';
  }
  constructor(iconRegistry: MatIconRegistry, sanitizer: DomSanitizer) { 
    iconRegistry.addSvgIcon(
      'visibility',
      sanitizer.bypassSecurityTrustResourceUrl('src/assets/img/examples/sharp-visibility-24px.svg'));
      
    iconRegistry.addSvgIcon(
      'visibility_off',

      sanitizer.bypassSecurityTrustResourceUrl('assets/img/examples/baseline-visibility_off-24px.svg'));
  }

  ngOnInit() {
  }

}
