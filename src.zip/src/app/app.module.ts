import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { RouterModule, Routes } from '@angular/router';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule }   from '@angular/common/http';

import {MatFormFieldModule} from '@angular/material/form-field';
import {MatIconModule} from '@angular/material/icon';
import {MatInputModule} from '@angular/material';
import {MatCardModule} from '@angular/material/card';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatListModule} from '@angular/material/list';
import {MatTableModule} from '@angular/material/table';
import {MatStepperModule} from '@angular/material/stepper';
import {MatButtonModule} from '@angular/material/button';

import { AppComponent } from './app.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { AdminRegisterComponentComponent } from './admin-register-component/admin-register-component.component';
import { TableComponent } from './table/table.component';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { CustomerIDComponent } from './customer-id/customer-id.component';


declare var require: any;
const routes: Routes = [
  { path: 'customerlogin',
  
 
  children : [
    { path: '',
    component:  CustomerLoginComponent
    },
    { path: 'entry',
    component:  CustomerIDComponent
    }
  ]
},

{ path: '',
  pathMatch: 'full',
  redirectTo: '/customerlogin'
  },
  { path: '**',
  pathMatch: 'full',
  redirectTo: '/customerlogin'
  }
]
@NgModule({
  declarations: [
    AppComponent,
    LoginComponentComponent,
    AdminRegisterComponentComponent,
    TableComponent,
    CustomerLoginComponent,
    CustomerIDComponent
  ],
  imports: [
    BrowserModule,
    MatFormFieldModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,
    MatInputModule,
    MatCardModule,
    HttpClientModule,
    MatGridListModule,
    MatListModule,
    MatTableModule,
    MatStepperModule,
    MatButtonModule,
    RouterModule.forRoot(routes, {useHash : true}),
  ],
  providers: [],
  bootstrap: [AppComponent],
  exports: [ RouterModule ]
})
export class AppModule { }
