import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormsModule, FormBuilder, ReactiveFormsModule } from '@angular/forms';
@Component({
  selector: 'app-customer-login',
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.css']
})
export class CustomerLoginComponent implements OnInit {
  form;
  constructor(private fb: FormBuilder) { 
    this.form = this.fb.group({
      customerId: [null]

    })
  }

  ngOnInit() {
  }

  submitCustomerID(e){

    console.log(e)

  }
}
