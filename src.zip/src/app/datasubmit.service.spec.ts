import { TestBed, inject } from '@angular/core/testing';

import { DatasubmitService } from './datasubmit.service';

describe('DatasubmitService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DatasubmitService]
    });
  });

  it('should be created', inject([DatasubmitService], (service: DatasubmitService) => {
    expect(service).toBeTruthy();
  }));
});
